import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Mainzer Fashion',
  description: 'Kuratierte Mode – entdecke einzigartige Kleidungsstücke',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="de">
      <body>
        {children}
      </body>
    </html>
  );
}
