'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';

const CATEGORIES = ['Oberteile', 'Hosen', 'Kleider', 'Röcke', 'Jacken', 'Mäntel', 'Schuhe', 'Accessoires', 'Sportswear', 'Sonstiges'];
const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '34', '36', '38', '40', '42', '44', '46', '36 (Schuhe)', '37', '38', '39', '40', '41', '42'];

export default function AdminPage() {
  const router = useRouter();
  const [uploading, setUploading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);

  const [form, setForm] = useState({
    title: '',
    description: '',
    price: '',
    size: '',
    category: '',
    gender: 'Unisex',
    condition: 'Gebraucht',
    status: 'verfügbar',
  });

  function handleChange(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  }

  function handleImageChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageFile(file);
    const reader = new FileReader();
    reader.onloadend = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setUploading(true);

    try {
      let image_url = '';

      if (imageFile) {
        const ext = imageFile.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
        const { error: uploadError } = await supabase.storage
          .from('product-images')
          .upload(fileName, imageFile, { cacheControl: '3600', upsert: false });

        if (uploadError) throw new Error('Bild-Upload fehlgeschlagen: ' + uploadError.message);

        const { data: urlData } = supabase.storage
          .from('product-images')
          .getPublicUrl(fileName);
        image_url = urlData.publicUrl;
      }

      const { error: insertError } = await supabase.from('products').insert([
        {
          title: form.title,
          description: form.description,
          price: parseFloat(form.price),
          size: form.size,
          category: form.category,
          gender: form.gender,
          condition: form.condition,
          status: form.status,
          image_url,
        },
      ]);

      if (insertError) throw new Error('Daten-Upload fehlgeschlagen: ' + insertError.message);

      setSuccess(true);
      setForm({ title: '', description: '', price: '', size: '', category: '', gender: 'Unisex', condition: 'Gebraucht', status: 'verfügbar' });
      setImagePreview(null);
      setImageFile(null);
      setTimeout(() => setSuccess(false), 4000);
    } catch (err: any) {
      setError(err.message || 'Unbekannter Fehler');
    } finally {
      setUploading(false);
    }
  }

  const inputClass = `
    w-full bg-white border border-charcoal/20 text-charcoal text-sm px-4 py-3
    focus:outline-none focus:border-blush transition-colors font-body
    placeholder:text-muted/50
  `;
  const labelClass = 'block text-xs uppercase tracking-widest text-muted font-body mb-1.5';

  return (
    <div className="min-h-screen bg-cream">
      {/* Admin Header */}
      <header className="bg-charcoal text-cream py-4 px-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/" className="text-cream/40 hover:text-cream text-xs uppercase tracking-widest transition-colors">
            ← Galerie
          </Link>
          <span className="text-cream/20">|</span>
          <span className="font-display text-xl tracking-[0.15em]">Admin</span>
        </div>
        <span className="text-xs text-cream/40 uppercase tracking-widest">Mainzer Fashion</span>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-10">
        <h1 className="font-display text-4xl font-light text-charcoal mb-2">
          Neues Produkt
        </h1>
        <p className="text-sm text-muted font-body mb-10">
          Fülle alle Felder aus. Das Produkt erscheint sofort in der Galerie.
        </p>

        {/* Success */}
        {success && (
          <div className="mb-6 bg-sage/10 border border-sage/30 text-sage px-4 py-3 text-sm font-body flex items-center gap-2">
            <svg className="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            Produkt erfolgreich hochgeladen! Es erscheint jetzt in der Galerie.
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 text-red-600 px-4 py-3 text-sm font-body">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Image Upload */}
          <div>
            <label className={labelClass}>Produktbild *</label>
            <div
              className={`relative border-2 border-dashed transition-colors cursor-pointer ${
                imagePreview ? 'border-blush' : 'border-charcoal/20 hover:border-blush'
              }`}
            >
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
              />
              {imagePreview ? (
                <div className="relative">
                  <img src={imagePreview} alt="Vorschau" className="w-full max-h-80 object-cover" />
                  <div className="absolute inset-0 bg-charcoal/0 hover:bg-charcoal/20 transition-colors flex items-center justify-center">
                    <span className="opacity-0 hover:opacity-100 text-white text-xs uppercase tracking-widest font-body transition-opacity">
                      Bild ändern
                    </span>
                  </div>
                </div>
              ) : (
                <div className="h-48 flex flex-col items-center justify-center text-muted/40 gap-3">
                  <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                  </svg>
                  <p className="text-xs uppercase tracking-widest font-body">Bild hochladen</p>
                  <p className="text-xs font-body">JPG, PNG, WEBP bis 10 MB</p>
                </div>
              )}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className={labelClass}>Titel *</label>
            <input
              type="text"
              name="title"
              value={form.title}
              onChange={handleChange}
              required
              placeholder="z.B. Vintage Levi's 501 Jeans"
              className={inputClass}
            />
          </div>

          {/* Description */}
          <div>
            <label className={labelClass}>Beschreibung</label>
            <textarea
              name="description"
              value={form.description}
              onChange={handleChange}
              rows={3}
              placeholder="Details zum Produkt, Besonderheiten, Materialien..."
              className={inputClass + ' resize-none'}
            />
          </div>

          {/* Price */}
          <div>
            <label className={labelClass}>Preis (€) *</label>
            <input
              type="number"
              name="price"
              value={form.price}
              onChange={handleChange}
              required
              min="0"
              step="0.01"
              placeholder="29.00"
              className={inputClass}
            />
          </div>

          {/* Size & Category */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={labelClass}>Größe *</label>
              <select name="size" value={form.size} onChange={handleChange} required className={inputClass}>
                <option value="">Größe wählen</option>
                {SIZES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className={labelClass}>Kategorie *</label>
              <select name="category" value={form.category} onChange={handleChange} required className={inputClass}>
                <option value="">Kategorie wählen</option>
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>

          {/* Gender / Condition / Status */}
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className={labelClass}>Geschlecht</label>
              <select name="gender" value={form.gender} onChange={handleChange} className={inputClass}>
                <option>Dame</option>
                <option>Herr</option>
                <option>Unisex</option>
              </select>
            </div>
            <div>
              <label className={labelClass}>Zustand</label>
              <select name="condition" value={form.condition} onChange={handleChange} className={inputClass}>
                <option>Neu</option>
                <option>Gebraucht</option>
              </select>
            </div>
            <div>
              <label className={labelClass}>Status</label>
              <select name="status" value={form.status} onChange={handleChange} className={inputClass}>
                <option value="verfügbar">Verfügbar</option>
                <option value="reserviert">Reserviert</option>
                <option value="verkauft">Verkauft</option>
              </select>
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={uploading}
            className="w-full bg-charcoal text-cream py-4 text-xs tracking-widest uppercase font-body hover:bg-blush transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
          >
            {uploading ? (
              <>
                <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Wird hochgeladen...
              </>
            ) : (
              'Produkt veröffentlichen'
            )}
          </button>
        </form>
      </main>
    </div>
  );
}
