'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import Header from '@/components/Header';
import { supabase, type Product } from '@/lib/supabase';

export default function ProductDetail() {
  const params = useParams();
  const router = useRouter();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [liked, setLiked] = useState(false);
  const [animating, setAnimating] = useState(false);

  useEffect(() => {
    if (params.id) fetchProduct(params.id as string);
  }, [params.id]);

  useEffect(() => {
    if (product) {
      const favorites = JSON.parse(localStorage.getItem('mf-favorites') || '[]');
      setLiked(favorites.includes(product.id));
    }
  }, [product]);

  async function fetchProduct(id: string) {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('id', id)
      .single();

    if (!error && data) setProduct(data as Product);
    setLoading(false);
  }

  const toggleLike = () => {
    if (!product) return;
    const favorites = JSON.parse(localStorage.getItem('mf-favorites') || '[]');
    let newFavorites;
    if (liked) {
      newFavorites = favorites.filter((id: string) => id !== product.id);
    } else {
      newFavorites = [...favorites, product.id];
    }
    localStorage.setItem('mf-favorites', JSON.stringify(newFavorites));
    setLiked(!liked);
    setAnimating(true);
    setTimeout(() => setAnimating(false), 300);
  };

  const statusColors: Record<string, string> = {
    verfügbar: 'bg-sage text-white',
    reserviert: 'bg-blush text-white',
    verkauft: 'bg-charcoal text-white',
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-cream">
        <Header />
        <div className="max-w-5xl mx-auto px-4 py-16 animate-pulse">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="aspect-[3/4] bg-charcoal/5" />
            <div className="space-y-4">
              <div className="h-8 bg-charcoal/5 rounded w-3/4" />
              <div className="h-6 bg-charcoal/5 rounded w-1/4" />
              <div className="h-24 bg-charcoal/5 rounded" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-cream">
        <Header />
        <div className="text-center py-24">
          <p className="font-display text-3xl font-light text-charcoal/30">Produkt nicht gefunden</p>
          <Link href="/" className="mt-4 inline-block text-sm text-blush hover:underline">
            Zurück zur Galerie
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream">
      <Header />
      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-16">
        {/* Back */}
        <button
          onClick={() => router.back()}
          className="flex items-center gap-2 text-xs text-muted hover:text-charcoal transition-colors mb-8 uppercase tracking-widest font-body"
        >
          ← Zurück
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-16">
          {/* Image */}
          <div className="relative aspect-[3/4] bg-white overflow-hidden">
            {product.image_url ? (
              <Image
                src={product.image_url}
                alt={product.title}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, 50vw"
                priority
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center text-muted/20">
                <svg className="w-20 h-20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex flex-col">
            {/* Status */}
            <span className={`inline-flex self-start px-3 py-1 text-xs tracking-widest uppercase font-body mb-4 ${statusColors[product.status]}`}>
              {product.status}
            </span>

            <h1 className="font-display text-4xl sm:text-5xl font-light text-charcoal leading-tight mb-2">
              {product.title}
            </h1>

            <p className="font-body text-3xl font-light text-charcoal mt-2 mb-6">
              {product.price.toFixed(2).replace('.', ',')} €
            </p>

            <p className="font-body text-sm text-muted leading-relaxed mb-8">
              {product.description}
            </p>

            {/* Details grid */}
            <div className="grid grid-cols-2 gap-4 border-t border-charcoal/10 pt-6 mb-8">
              {[
                { label: 'Größe', value: product.size },
                { label: 'Kategorie', value: product.category },
                { label: 'Geschlecht', value: product.gender },
                { label: 'Zustand', value: product.condition },
              ].map(({ label, value }) => (
                <div key={label}>
                  <p className="text-xs text-muted/60 uppercase tracking-widest font-body mb-1">{label}</p>
                  <p className="text-sm text-charcoal font-body font-medium">{value}</p>
                </div>
              ))}
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-3 mt-auto">
              {product.status === 'verfügbar' && (
                <a
                  href={`https://instagram.com/mainzer.fashion`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 bg-charcoal text-cream py-4 text-xs tracking-widest uppercase font-body hover:bg-blush transition-colors duration-300"
                >
                  <InstagramIcon />
                  Auf Instagram anfragen
                </a>
              )}

              <button
                onClick={toggleLike}
                className={`flex items-center justify-center gap-2 py-4 px-6 text-xs tracking-widest uppercase font-body border transition-colors ${
                  liked
                    ? 'border-rose-400 text-rose-500 bg-rose-50'
                    : 'border-charcoal/20 text-charcoal hover:border-charcoal'
                }`}
              >
                <svg
                  className={`w-4 h-4 ${animating ? 'heart-pop' : ''}`}
                  fill={liked ? 'currentColor' : 'none'}
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
                {liked ? 'Favorit' : 'Merken'}
              </button>
            </div>

            {product.status !== 'verfügbar' && (
              <p className="mt-4 text-xs text-muted font-body text-center">
                {product.status === 'verkauft'
                  ? 'Dieses Stück wurde bereits verkauft.'
                  : 'Dieses Stück ist aktuell reserviert. Bei Interesse trotzdem melden!'}
              </p>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

function InstagramIcon() {
  return (
    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
    </svg>
  );
}
