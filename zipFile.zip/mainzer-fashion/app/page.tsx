'use client';

import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import ProductCard from '@/components/ProductCard';
import FilterBar from '@/components/FilterBar';
import { supabase, type Product } from '@/lib/supabase';

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedGender, setSelectedGender] = useState('');

  useEffect(() => {
    fetchProducts();
  }, []);

  async function fetchProducts() {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
      setProducts(data as Product[]);
    }
    setLoading(false);
  }

  const categories = [...new Set(products.map((p) => p.category))].filter(Boolean);
  const sizes = [...new Set(products.map((p) => p.size))].filter(Boolean).sort();

  const filtered = products.filter((p) => {
    if (selectedCategory && p.category !== selectedCategory) return false;
    if (selectedSize && p.size !== selectedSize) return false;
    if (selectedGender && p.gender !== selectedGender) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-cream">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Hero */}
        <div className="mb-10 border-b border-charcoal/10 pb-8">
          <p className="font-display text-sm tracking-[0.3em] uppercase text-blush mb-2">
            Kuratierte Kollektion
          </p>
          <h1 className="font-display text-5xl sm:text-7xl font-light text-charcoal leading-none">
            Mode mit
            <br />
            <span className="italic text-blush">Geschichte</span>
          </h1>
          <p className="mt-4 font-body text-sm text-muted max-w-md leading-relaxed">
            Entdecke einzigartige Kleidungsstücke. Bei Interesse einfach auf Instagram schreiben.
          </p>
        </div>

        {/* Filters */}
        <FilterBar
          categories={categories}
          sizes={sizes}
          selectedCategory={selectedCategory}
          selectedSize={selectedSize}
          selectedGender={selectedGender}
          onCategoryChange={setSelectedCategory}
          onSizeChange={setSelectedSize}
          onGenderChange={setSelectedGender}
        />

        {/* Count */}
        <div className="mb-6 flex items-center justify-between">
          <p className="text-xs text-muted font-body uppercase tracking-widest">
            {filtered.length} Artikel
          </p>
        </div>

        {/* Grid */}
        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="bg-white animate-pulse">
                <div className="aspect-[3/4] bg-charcoal/5" />
                <div className="p-3 space-y-2">
                  <div className="h-4 bg-charcoal/5 rounded w-3/4" />
                  <div className="h-3 bg-charcoal/5 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-24">
            <p className="font-display text-3xl font-light text-charcoal/30 mb-2">
              Keine Artikel gefunden
            </p>
            <p className="font-body text-sm text-muted">
              Probiere einen anderen Filter
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
            {filtered.map((product, index) => (
              <div key={product.id} className="fade-in-up" style={{ animationDelay: `${index * 50}ms`, opacity: 0, animationFillMode: 'forwards' }}>
                <ProductCard product={product} index={index} />
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-20 border-t border-charcoal/10 py-8 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <span className="font-display text-lg tracking-[0.15em] text-charcoal/40">
            MAINZER FASHION
          </span>
          <a
            href="https://instagram.com/mainzer.fashion"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-muted hover:text-blush transition-colors font-body tracking-widest uppercase"
          >
            @mainzer.fashion
          </a>
          <p className="text-xs text-muted/60 font-body">
            Kein Webshop – Anfragen nur via Instagram
          </p>
        </div>
      </footer>
    </div>
  );
}
