/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ['var(--font-cormorant)', 'serif'],
        body: ['var(--font-dm-sans)', 'sans-serif'],
      },
      colors: {
        cream: '#F5F0E8',
        charcoal: '#1A1A1A',
        blush: '#C9A882',
        muted: '#8A8A8A',
        sage: '#6B7B5E',
      },
    },
  },
  plugins: [],
};
