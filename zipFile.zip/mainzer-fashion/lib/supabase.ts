import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Product = {
  id: string;
  title: string;
  description: string;
  price: number;
  size: string;
  category: string;
  gender: 'Herr' | 'Dame' | 'Unisex';
  condition: 'Neu' | 'Gebraucht';
  status: 'verfügbar' | 'reserviert' | 'verkauft';
  image_url: string;
  created_at: string;
};
