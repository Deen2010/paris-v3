'use client';

interface FilterBarProps {
  categories: string[];
  sizes: string[];
  selectedCategory: string;
  selectedSize: string;
  selectedGender: string;
  onCategoryChange: (val: string) => void;
  onSizeChange: (val: string) => void;
  onGenderChange: (val: string) => void;
}

export default function FilterBar({
  categories,
  sizes,
  selectedCategory,
  selectedSize,
  selectedGender,
  onCategoryChange,
  onSizeChange,
  onGenderChange,
}: FilterBarProps) {
  const genders = ['Alle', 'Dame', 'Herr', 'Unisex'];

  const selectClass = `
    appearance-none bg-cream border border-charcoal/20 text-charcoal text-xs
    tracking-widest uppercase px-4 py-2 pr-8 cursor-pointer hover:border-blush
    transition-colors focus:outline-none focus:border-blush font-body
  `;

  return (
    <div className="flex flex-wrap items-center gap-3 py-4">
      <span className="text-xs text-muted uppercase tracking-widest font-body hidden sm:block">
        Filter:
      </span>

      {/* Gender */}
      <div className="flex gap-1">
        {genders.map((g) => (
          <button
            key={g}
            onClick={() => onGenderChange(g === 'Alle' ? '' : g)}
            className={`px-3 py-1.5 text-xs tracking-widest uppercase font-body transition-colors ${
              (g === 'Alle' && selectedGender === '') || selectedGender === g
                ? 'bg-charcoal text-cream'
                : 'bg-transparent text-charcoal/60 hover:text-charcoal border border-charcoal/20'
            }`}
          >
            {g}
          </button>
        ))}
      </div>

      {/* Category */}
      <div className="relative">
        <select
          value={selectedCategory}
          onChange={(e) => onCategoryChange(e.target.value)}
          className={selectClass}
        >
          <option value="">Kategorie</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <div className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-charcoal/40">
          ↓
        </div>
      </div>

      {/* Size */}
      <div className="relative">
        <select
          value={selectedSize}
          onChange={(e) => onSizeChange(e.target.value)}
          className={selectClass}
        >
          <option value="">Größe</option>
          {sizes.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <div className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-charcoal/40">
          ↓
        </div>
      </div>

      {/* Reset */}
      {(selectedCategory || selectedSize || selectedGender) && (
        <button
          onClick={() => {
            onCategoryChange('');
            onSizeChange('');
            onGenderChange('');
          }}
          className="text-xs text-muted hover:text-charcoal transition-colors underline underline-offset-2 font-body"
        >
          Zurücksetzen
        </button>
      )}
    </div>
  );
}
